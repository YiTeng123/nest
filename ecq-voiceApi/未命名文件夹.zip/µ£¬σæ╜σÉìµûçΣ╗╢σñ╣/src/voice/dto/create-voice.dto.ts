export class CreateVoiceDto {}
