export class Voice {}
