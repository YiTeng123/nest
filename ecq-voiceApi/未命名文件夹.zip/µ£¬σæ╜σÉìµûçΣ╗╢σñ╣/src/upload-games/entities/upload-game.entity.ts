export class UploadGame {}
