export class CreateUploadGameDto {}
