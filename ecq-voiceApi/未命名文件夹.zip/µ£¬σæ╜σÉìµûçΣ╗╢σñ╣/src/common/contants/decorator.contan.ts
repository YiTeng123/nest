
/* 登陆接口无需 JWT 校验 */
export const PUBLIC_KEY = 'PUBLIC_KEY';

/* ROLES 校验需要的 KEY */
export const ROLES_KEY = 'roles';
