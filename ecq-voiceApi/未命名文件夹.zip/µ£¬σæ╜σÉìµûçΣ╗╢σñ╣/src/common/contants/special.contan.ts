
/* ROLES 需要特殊处理不进行 JWT的路由 如 监控页面 等 */
export const SPECIAL_ROUTES = ['/api/status', '/api/doc/swagger-api'];
