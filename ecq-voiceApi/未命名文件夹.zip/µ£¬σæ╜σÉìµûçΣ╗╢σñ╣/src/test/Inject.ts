import { Injectable } from "@nestjs/common";

@Injectable()
export class test{
    UFO(){
        console.log('2323')
    }
}