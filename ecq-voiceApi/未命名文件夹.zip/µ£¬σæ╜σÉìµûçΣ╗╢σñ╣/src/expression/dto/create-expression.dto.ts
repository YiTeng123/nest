export class CreateExpressionDto {}
