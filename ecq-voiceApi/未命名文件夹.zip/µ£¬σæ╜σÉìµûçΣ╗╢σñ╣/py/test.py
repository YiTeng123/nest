import sys


v0 = sys.argv[1]
# v1 = eval(sys.argv[2])
# v2 = eval(sys.argv[3])


def main():
    print('i am python')
    print(v0)
    # print(v1 + v2)


if __name__ == '__main__':
    main()
    

