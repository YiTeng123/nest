from moviepy.editor import *
import os

# video = VideoFileClip("./Coco-1.mp4")
#video = VideoFileClip("./webm.mp4")
#audio = video.audio
#audio.write_audiofile('webm.wav')

command = "ffmpeg -loglevel quiet -i {} -ac 1 -ar 128000 {}".format("./webm.mp4", "test4.wav")
os.system(command)
