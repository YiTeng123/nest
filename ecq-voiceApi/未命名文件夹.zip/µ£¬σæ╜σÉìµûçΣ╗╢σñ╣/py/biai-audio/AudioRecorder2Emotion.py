# -*- coding: utf-8 -*-
"""
Created on Mon Aug 23 11:06:03 2021

@author: Bangwei Ye, BIAI, Inc.
Email: leafhelpwei@163.com
Copyright: BIAI, Inc.

"""
import keras
import librosa
import numpy as np
import os
import pandas as pd
import pyaudio
import wave

'''
自主录音并且调用训练好的模型来预测录音音频的说话人的情绪，同时对比不同模型的预测效果。
'''

#### value
input_filename = "input.wav"               # 麦克风采集的语音输入保存到本地文件的文件名，同时作为预测的目标文件
# 输入文件"input.wav"的保存路径
input_filepath = os.getcwd()  # 这里保存到当下路径，也可以修改为其他路径
in_path = os.path.join(input_filepath, input_filename) #组合成绝对路径

## 模型绝对路径
# 多个模型路径用来比较不同模型的预测效果
#MODEL_DIR_PATH = "D:/Python Project/Speech-Emotion-Analyzer-master/saved_models/f1emotion_Model.h5"
#MODEL_DIR_PATH1 = "D:/Python Project/Speech-Emotion-Analyzer-master/saved_models/f2emotion_Model.h5"
#MODEL_DIR_PATH2 = "D:/Python Project/Speech-Emotion-Analyzer-master/saved_models/addf1emotion_Model.h5"

# single model
MODEL_DIR_PATH = "A2E_Model.h5"

#### Get audio
def get_audio(filepath):
    
    aa = str(input("是否开始录音？   （y/N）"))
    if aa == str("y") :
        CHUNK = 256
        FORMAT = pyaudio.paInt16
        CHANNELS = 1                # 声道数
        RATE = 11025                # 采样率
        RECORD_SECONDS = 4     #录音时长
        WAVE_OUTPUT_FILENAME = filepath
        p = pyaudio.PyAudio()

        stream = p.open(format=FORMAT,
                        channels=CHANNELS,
                        rate=RATE,
                        input=True,
                        frames_per_buffer=CHUNK)

        print("*"*10, "开始录音：请在4秒内输入语音","*"*10)
        frames = []
        for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
            data = stream.read(CHUNK)
            frames.append(data)
        print("*"*10, "录音结束\n")

        stream.stop_stream()
        stream.close()
        p.terminate()

        wf = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(p.get_sample_size(FORMAT))
        wf.setframerate(RATE)
        wf.writeframes(b''.join(frames))
        wf.close()
    elif aa == str("N"):
        exit()
    else:
        print("无效输入，请重新选择")
        get_audio(in_path)
        
#### 2Emotin
class LivePredictions:
    """
    Main class of the application.
    """

    def __init__(self, file,model_file):
        """
        Init method is used to initialize the main parameters.
        """
        self.file = file
        self.path = model_file
        self.loaded_model = keras.models.load_model(self.path)

    def make_predictions(self):
        """
        Method to process the files and create your features.
        """
        time_long=librosa.get_duration(filename=self.file)
        dt=2    #duration
        predictions=[]
        pre = []
        for oset in range( int(time_long-dt) ):
            X, sample_rate = librosa.load(self.file, res_type='kaiser_fast',duration=dt,sr=22050*2,offset=oset)
            sample_rate = np.array(sample_rate)
            mfccs = np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40),axis=0)
            featurelive = mfccs
            livedf2 = featurelive
            livedf2= pd.DataFrame(data=livedf2)
            livedf2 = livedf2.stack().to_frame().T
            twodim= np.expand_dims(livedf2, axis=2)
            livepreds = self.loaded_model.predict( twodim )
            livepreds1=livepreds.argmax(axis=1)
            liveabc = livepreds1.astype(int).flatten()
            pre.append(liveabc)
            
        most_pre = max(pre, key=pre.count)
        livepredictions = self.inverse_transform(most_pre)
        predictions.append(livepredictions)
        
        return predictions

    @staticmethod
    def inverse_transform(pred):
        """
        Method to convert the predictions (int) into human readable strings.
        """
        
        '''label_conversion = {'0': 'female_angry',
                            '1': 'female_calm',
                            '2': 'female_fearful',
                            '3': 'female_happy',
                            '4': 'female_sad',
                            '5': 'male_angry',
                            '6': 'male_calm',
                            '7': 'male_fearful',
                            '8': 'male_happy',
                            '9': 'male_sad',
                            '10': 'uncertainly'}'''
        
        label_conversion = {'0': 'angry',
                            '1': 'calm',
                            '2': 'fearful',
                            '3': 'happy',
                            '4': 'sad',
                            '5': 'surprise'}

        for key, value in label_conversion.items():
            if int(key) == pred:
                label = value
        return label
    
#### main
if __name__ == '__main__':
    get_audio(in_path)
    live_prediction1 = LivePredictions(file=in_path,model_file=MODEL_DIR_PATH1)
    live_prediction2 = LivePredictions(file=in_path,model_file=MODEL_DIR_PATH2)
    live_prediction = LivePredictions(file=in_path,model_file=MODEL_DIR_PATH)
    
    result1=live_prediction1.make_predictions()
    result=live_prediction.make_predictions()
    result2=live_prediction2.make_predictions()
    
    ## 比较多个模型预测的结果
    print(result)
    print(result1)
    print(result2)
    
