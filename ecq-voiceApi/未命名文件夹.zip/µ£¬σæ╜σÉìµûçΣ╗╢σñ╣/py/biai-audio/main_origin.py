# -*- coding: utf-8 -*-
"""
Created on Mon Aug 23 11:06:03 2021

@author: Bangwei Ye, BIAI, Inc.
Email: leafhelpwei@163.com
Copyright: BIAI, Inc.

"""

'''
通过及时录音获取说话人的情绪的GUI设计界面
'''

# 导入消息对话框子模块
import keras
from keras.models import load_model
import librosa
import numpy as np
import os
import argparse
import pandas as pd
import pyaudio
import wave

#from PIL import Image, ImageTk


#### 图片导入
from memory_pic import *    # 无需一个个导入；memory.py是已经处理好的保存所需图片的数据文件
import base64

def get_pic(pic_code, pic_name):
    # 将图片数据从py文件里反解为图片
    image = open(pic_name, 'wb')
    image.write(base64.b64decode(pic_code))
    image.close()

parser=argparse.ArgumentParser()
parser.add_argument('--audio_path', help = 'path/to/audio file', required=False)
parser.add_argument('--video_path', help = 'path/to/video file', required=False)
opt=parser.parse_args()
audio_path = opt.audio_path  #obtain current video path
video_path = opt.video_path

#### Value
input_filename = "input.wav"               # 麦克风采集的语音输入
# 输入文件的path
input_filepath = os.getcwd()  #当下路径
'''
if audio_path == None:
    in_path = os.path.join(input_filepath, input_filename) #组合成绝对路径
else:
    in_path=audio_path
'''
if video_path != None:
    (file_path, ext) = os.path.splitext(video_path)
    audio_path=file_path+".wav"
    command = "ffmpeg -loglevel quiet -i {} -ac 1 -ar 128000 {}".format(video_path, audio_path)
    os.system(command)
    in_path=audio_path 
elif audio_path!= None: 
    in_path=audio_path
else:
    in_path = os.path.join(input_filepath, input_filename) #组合成绝对路径

# 模型路径
#MODEL_DIR_PATH = "D:/Python Project/Speech-Emotion-Analyzer-master/saved_models/"

# 录音参数
CHUNK = 256
FORMAT = pyaudio.paInt16
CHANNELS = 1                # 声道数
RATE = 11025                # 采样率
RECORD_SECONDS = 4     #录音时长
WAVE_OUTPUT_FILENAME = in_path

get=True

######## 声明函数

#### 2Emotin
class LivePredictions:
    """
    调用模型，将输入的音频文件返回为音频说话人的情绪
    """

    def __init__(self, file):
        """
        Init method is used to initialize the main parameters.
        """
        self.file = file
#        self.path = './f1emotion_Model.h5'
        self.path = './A2E_Model.h5'
        self.loaded_model = load_model(self.path)

    def make_predictions(self):
        """
        Method to process the files and create your features.
        """
        X, sample_rate = librosa.load(self.file, res_type='kaiser_fast',duration=2.5,sr=22050*2,offset=0.5)
        sample_rate = np.array(sample_rate)
        mfccs = np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=13),axis=0)
        featurelive = mfccs
        livedf2 = featurelive
        livedf2= pd.DataFrame(data=livedf2)
        livedf2 = livedf2.stack().to_frame().T
        twodim= np.expand_dims(livedf2, axis=2)
        livepreds = self.loaded_model.predict( twodim )
        livepreds1=livepreds.argmax(axis=1)
        liveabc = livepreds1.astype(int).flatten()
#        print("debug...",liveabc)
        livepredictions = self.inverse_transform(liveabc)
        return livepredictions

    @staticmethod
    def inverse_transform(pred):
        """
        Method to convert the predictions (int) into human readable strings.
        """
        
        '''label_conversion = {'0': 'female_angry',
                            '1': 'female_calm',
                            '2': 'female_fearful',
                            '3': 'female_happy',
                            '4': 'female_sad',
                            '5': 'male_angry',
                            '6': 'male_calm',
                            '7': 'male_fearful',
                            '8': 'male_happy',
                            '9': 'male_sad',
                            '10': 'uncertainly'}'''
        
        label_conversion = {'0': '你似乎有些不高兴',
                            '1': '你现在应该挺平静',
                            '2': '你貌似在害怕什么',
                            '3': '你的心情应该不错',
                            '4': '你可能需要人安慰',
                            '5': '你很惊喜或惊吓吧'}
        label_conversion = {'0': 'angry',
                            '1': 'calm',
                            '2': 'fearful',
                            '3': 'happy',
                            '4': 'sad',
                            '5': 'angry'}

        label=''
        for key, value in label_conversion.items():
            if int(key) == pred:
                label = value
        return label
    

## 图片缩放显示为可处理格式
def resize( pil_image):  
    ''' 
    resize a pil_image object so it will fit into 
    a box of size w_box times h_box, but retain aspect ratio 
    对一个pil_image对象进行缩放，让它在一个矩形框内，还能保持比例 
    '''  
    w, h = pil_image.size 
    w_box=300
    h_box=160
    f1 = 1.0*w_box/w # 1.0 forces float division in Python2  
    f2 = 1.0*h_box/h  
    factor = min([f1, f2])  
    #print(f1, f2, factor) # test  
    # use best down-sizing filter  
    width = int(w*factor)  
    height = int(h*factor)  
    reimg = pil_image.resize((width, height), Image.ANTIALIAS)
    reimg = ImageTk.PhotoImage(reimg)  # 转为可处理格式
    return reimg


## btn1:Release的响应函数
def getaudio():
    '''
    调用录音设备
    '''
    global data,frames,get
    frames=[]
    data=[]
    print('正在录音')
    p = pyaudio.PyAudio()
    try:
        stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)
        for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
            data = stream.read(CHUNK)
            frames.append(data)
        print('==========================录音结束==========================')
    
    
        stream.stop_stream()
        stream.close()
        p.terminate()
    
        wf = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(p.get_sample_size(FORMAT))
        wf.setframerate(RATE)
        wf.writeframes(b''.join(frames))
        wf.close()
        get= True
    except:
        AudioError()  # 录音失败时返回错误

## 分析情绪
def emotion():
    '''
    返回情绪发泄结果
    '''
    stop_emotion=False
    if get:
        live_prediction = LivePredictions(file=in_path)
        result=live_prediction.make_predictions()
        stop_emotion=True
        return result
    elif stop_emotion==False:
        emotion()
    else:
        exit()

## 情绪对话框
def Toemotion():
    answer=True
    if answer:
        result=emotion()

        # 情绪对应表情包
        label_conversion = {'你似乎有些不高兴': 'female_angry.gif',
                            '你现在应该挺平静': 'female_calm.jfif',
                            '你貌似在害怕什么': 'female_fearful.jfif',
                            '你的心情应该不错': 'female_happy.jfif',
                            '你可能需要人安慰': 'female_sad.jfif',
                            '你很惊喜或惊吓吧': 'male_fearful.jfif'}

       
## 关闭窗口时的响应函数
def closetk():
    '''
    删除缓存的录音文件"inout.wav"
    '''
    res=os.listdir(input_filepath)
    if 'input.wav' in res:
        os.remove('input.wav')

#getaudio()
print(emotion())  

#### 在命令行窗口调用，实现py文件打包为程序，运行代码：
# pyinstaller -w A2E.py --hidden-import=PIL.module

## 注意在最后dist包里加入文件夹librosa,模型文件"f1emotion_Model.h5"
#### 发生错误：RecursionError: maximum recursion depth exceeded while calling a Python object
# 解决办法：在当下文件夹找到A2E.spec文件，打开，在上面加上

#import sys  # 导入sys模块
#sys.setrecursionlimit(3000)  # 将默认的递归深度修改为3000

# 然后在命令行窗口运行
# pyinstaller -w A2E.spec
